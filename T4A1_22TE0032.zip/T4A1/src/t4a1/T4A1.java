package t4a1;

import java.util.Scanner;

public class T4A1 {

    public static void main(String[] args) {
        int interruptor = 0;
        while (interruptor != 's') {
            //ejercicio1();
            //ejercicio2();
            //ejercicio3();
            ejercicio4();

        }
    }

    //Escribir un programa que solicite un n�mero positivo y nos muestre desde 1 
    //hasta el valor ingresado de uno en uno. Ejemplo: Si ingresamos 30 se debe 
    //mostrar en pantalla los n�meros del 1 al 30.
    public static void ejercicio1() {
        Scanner scanner = new Scanner(System.in);
        int n = 0;

        System.out.println("Secuencia de numeros ");

        System.out.println("Ingrese el numero limite ");
        int l = scanner.nextInt();
        while (n < l) {
            n++;
            System.out.println(n);
        }

    }

    //Una maquiladora confecciona pantalones y recibe un lote de N piezas para un cliente X.
    //Crear un programa en Java que solicite la cantidad de piezas a confeccionar y luego se 
    //ingrese las respectivas tallas que pueden ser S, M, L y XL. Luego, imprimir en pantalla 
    //la cantidad de piezas confeccionadas por talla.
    public static void ejercicio2() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Piezas a confeccionar");

        int p = scanner.nextInt();
        int n = 0;
        int ts = 0;
        int tm = 0;
        int tl = 0;
        int txl = 0;

        while (n < p) {
            n++;
            System.out.println("\n Talla: ");
            String talla = scanner.next();

            if (talla.equals("S") || talla.equals("s")) {
                ts++;
            } else if (talla.equals("M") || talla.equals("m")) {
                tm++;
            } else if (talla.equals("L") || talla.equals("l")) {
                tl++;
            } else {
                txl++;
            }
        }
        System.out.println("Cantidad por talla: \n"
                + "Chica(S)\t\t: " + ts + "\n"
                + "Mediana(M\t): " + tm + "\n"
                + "Grande(L)\t: " + tl + "\n"
                + "Extragrande(XL\t : " + txl);

    }

    //Escribir un programa en Java que solicite N calificaciones de estudiantes 
    //en una escala del 0 al 100 y que informe cu�ntos tienen calificaci�n mayor o
    //igual a 70 y cu�ntos tienen una calificaci�n menor. 
    public static void ejercicio3() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la calificacion en una escala del 0 al 100");
        System.out.println("Total de estudiantes");
        int e = scanner.nextInt();
        int n = 0;
        int ea = 0;
        int er = 0;
        //int c = scanner.nextInt();

        while (n < e) {
            n++;

            System.out.println("\n Calificacion: ");
            int c = scanner.nextInt();

            if (c >= 70) {
                ea++;
            } else {
                er++;
            }

        }

        System.out.println("Cantidad de estudiantes: \n"
                + "Aprobados\t\t: " + ea
                + "Reprobados\t\t: " + er);
    }
    //4. Escribir un programa en Java que imprima los m�ltiplos 
    //del n�mero que indique el usuario hasta la cantidad deseada. 
    //El usuario debe indicar el m�ltiplo y el n�mero hasta el cual quiere llegar

    public static void ejercicio4() {
        Scanner scanner = new Scanner(System.in);

        int l; 
        int m; 
        int i; 

        System.out.print("Ingresa el multiplo: ");
        m = scanner.nextInt();

        System.out.print("Ingresa el limite: ");
        l = scanner.nextInt();

        for (i = 1; i <= l; i++) {

            if (i % m == 0) {
                System.out.println(i);
            }

        }

    }
}
